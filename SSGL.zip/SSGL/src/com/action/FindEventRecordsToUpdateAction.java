package com.action;

import java.util.Map;
import com.service.*;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ActionContext;

//查找全部对象
public class FindEventRecordsToUpdateAction extends ActionSupport 
{
//	private static final long serialVersionUID = 1L;
	private EventServiceInt eventService;

	



	public EventServiceInt getEventService() {
		return eventService;
	}





	public void setEventService(EventServiceInt eventService) {
		this.eventService = eventService;
	}





	@SuppressWarnings("unchecked")
	public String execute() throws Exception {
		eventService = new EventServiceImpl();
		Map request = (Map)ActionContext.getContext().get("request");
		request.put("Recordslist", eventService.findEvent());
		return "success";
	}
}
