package com.action;

import com.service.*;
import com.vo.Event_recordVO;
import com.opensymphony.xwork2.ActionSupport;

import com.po.Event_recordPO;

//更新一个对象
public class EventUpdateAction extends ActionSupport
{
	private EventServiceInt eventService;
    private Event_recordVO eventVo;
	
	
    
	public EventServiceInt getEventService() {
		return eventService;
	}



	public void setEventService(EventServiceInt eventService) {
		this.eventService = eventService;
	}







	public Event_recordVO getEventVo() {
		return eventVo;
	}



	public void setEventVo(Event_recordVO eventVo) {
		this.eventVo = eventVo;
	}



	public String execute() throws Exception {
		eventService = new EventServiceImpl();
		eventService.updateEvent(eventVo);
		return "success";
	}
    
}

