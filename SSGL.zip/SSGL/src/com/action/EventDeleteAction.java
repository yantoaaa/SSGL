package com.action;

import com.service.*;

import com.po.Event_recordPO;
import com.opensymphony.xwork2.ActionSupport;

//删除一个对象
public class EventDeleteAction extends ActionSupport
{
	private EventServiceInt eventService;
    private Event_recordPO eventPo;

	

	public EventServiceInt getEventService() {
		return eventService;
	}



	public void setEventService(EventServiceInt eventService) {
		this.eventService = eventService;
	}



	public Event_recordPO getEventPo() {
		return eventPo;
	}



	public void setEventPo(Event_recordPO eventPo) {
		this.eventPo = eventPo;
	}



	public String execute() throws Exception {
		
		eventService = new EventServiceImpl();
		eventService.deleteEvent(eventPo);
		return "success";
	}
}
