package com.action;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import com.service.*;
import com.opensymphony.xwork2.ActionSupport;

import com.po.Event_recordPO;
import com.opensymphony.xwork2.ActionContext;

//查找全部对象
public class FindEventByTime extends ActionSupport 
{
//	private static final long serialVersionUID = 1L;
	private EventServiceInt eventService;
	private String Hosttime;

	



	public EventServiceInt getEventService() {
		return eventService;
	}





	public void setEventService(EventServiceInt eventService) {
		this.eventService = eventService;
	}







	public String getHosttime() {
		return Hosttime;
	}





	public void setHosttime(String hosttime) {
		Hosttime = hosttime;
	}





	@SuppressWarnings("unchecked")
	public String execute() throws Exception {
		eventService = new EventServiceImpl();

		
		Map request = (Map)ActionContext.getContext().get("request");
		request.put("EventRecordslist", eventService.findEventBytime(Hosttime));
		
		
		return "success";
	}
}
