package com.action;

import com.service.*;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import com.po.Event_recordPO;

//查找一个对象
public class FindEventToAuditAction extends ActionSupport
{
	private EventServiceInt eventService;
	

	public EventServiceInt getEventService() {
		return eventService;
	}


	public void setEventService(EventServiceInt eventService) {
		this.eventService = eventService;
	}


	






	@SuppressWarnings("unchecked")
	public String execute() throws Exception
	{
		eventService = new EventServiceImpl();
		Map request = (Map)ActionContext.getContext().get("request");
		request.put("Recordslist", eventService.findEventToAudit());
		
		return "success";
	}
}

