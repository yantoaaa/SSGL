package com.action;

import com.service.*;
import com.vo.Event_recordVO;
import com.opensymphony.xwork2.ActionSupport;

import com.po.Event_recordPO;

//更新一个对象
public class EventFailureAction extends ActionSupport
{
	private EventServiceInt eventService;
    private Event_recordPO eventPo;
	
	
    
	public EventServiceInt getEventService() {
		return eventService;
	}



	public void setEventService(EventServiceInt eventService) {
		this.eventService = eventService;
	}





	public Event_recordPO getEventPo() {
		return eventPo;
	}



	public void setEventPo(Event_recordPO eventPo) {
		this.eventPo = eventPo;
	}



	public String execute() throws Exception {
		eventService = new EventServiceImpl();
		eventService.FailureEvent(eventPo);
		return "success";
	}
    
}

