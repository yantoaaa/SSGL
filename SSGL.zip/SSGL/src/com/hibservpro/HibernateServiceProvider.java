package com.hibservpro;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;

//Hibernate鏈嶅姟鎻愪緵鑰�
public class HibernateServiceProvider {
	private static SessionFactory sessionFactory = null;
	
//閰嶇疆鏂囦欢涓敞鍐岀殑鏄槧灏勬枃浠�,璋冪敤Configuration()鏂规硶锛�
//	private static Configuration configuration = new Configuration();
	
//閰嶇疆鏂囦欢涓敞鍐岀殑鏄敞閲婃槧灏凱O绫�,璋冪敤AnnotationConfiguration()鏂规硶锛�	
	private static Configuration configuration = new AnnotationConfiguration();

    //鏋勯�犳柟娉�	
	public HibernateServiceProvider()
	{
		initHibernate();
	}    

    //鍒濆鍖杝essionFactory瀹炰緥锛�
	public static synchronized void initHibernate() throws HibernateException
	{    
    	if(sessionFactory == null)
    	try {
    			configuration.configure();   //鍚姩hibernate
    			sessionFactory = configuration.buildSessionFactory();   //鍒涘缓SessionFactory瀹炰緥

    		} catch (HibernateException he) 
    		{
    			System.err.println(" Error Creating SessionFactory ");
    			throw he;
    		}    		
    }	
	
    //閲嶆柊鍒涘缓SessionFactory瀹炰緥
	public static void rebuildSessionFactory() throws HibernateException
	{
		try {
			configuration.configure();
			sessionFactory = configuration.buildSessionFactory();
		} catch (HibernateException he) {
			System.err.println(" Error Creating SessionFactory ");
			throw he;
		}
	}
	
    //鑾峰彇Session瀹炰緥
	public Session getSession() throws HibernateException {
		if (sessionFactory == null) 
		{
			rebuildSessionFactory();
		}
		Session session = sessionFactory.openSession();
        return session;
    }
	
	public void closeSessionFactory() throws HibernateException
	{
		sessionFactory.close();
	}
}
