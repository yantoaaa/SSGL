package com.service;

import java.util.ArrayList;
import java.util.List;
import com.dao.*;

import com.po.Event_recordPO;
import com.vo.Event_recordVO;



public class EventServiceImpl implements EventServiceInt 
{
	private Event_recordPO eventPo;
	private EventDAOInt eventDao;
	
//1:增
	public void saveEvent(Event_recordVO eventVo)
	{
		eventDao = new EventDAOImpl();
		eventPo = new Event_recordPO();

		eventPo.setEventname(eventVo.getEventname());
		eventPo.setEventdetail(eventVo.getEventdetail());
		eventPo.setHosttime(eventVo.getHosttime());
		eventPo.setApplicator(eventVo.getApplicator());
		eventPo.setTeacher(eventVo.getTeacher());
		eventPo.setHost(eventVo.getHost());
		eventPo.setHostplace(eventVo.getHostplace());
		eventPo.setEquipment(eventVo.getEquipment());
		eventPo.setStatus("待审核");
		try 
		{
			eventDao.saveEvent(eventPo);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

//2: 删除  真删
	public void deleteEvent(Event_recordPO eventPo)
		{
			eventDao = new EventDAOImpl();
			try 
			{
				eventDao.deleteByOid(eventPo.getOid());
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}

//改
	public void updateEvent(Event_recordVO eventVo)
		{
			eventDao = new EventDAOImpl();	
			eventPo = new Event_recordPO();
			eventPo.setOid(eventVo.getOid());
			eventPo.setEventname(eventVo.getEventname());
			eventPo.setEventdetail(eventVo.getEventdetail());
			eventPo.setHosttime(eventVo.getHosttime());
			eventPo.setApplicator(eventVo.getApplicator());
			eventPo.setTeacher(eventVo.getTeacher());
			eventPo.setHost(eventVo.getHost());
			eventPo.setHostplace(eventVo.getHostplace());
			eventPo.setEquipment(eventVo.getEquipment());
			try 
			{
				eventDao.updateEventRecord(eventPo);
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
	
//按时间查找  
	public List<Event_recordPO> findEventBytime(String Hosttime)
	{
		List<Event_recordPO> result = new ArrayList<Event_recordPO>();
		eventDao = new EventDAOImpl();
		try 
		{
			result = eventDao.findEventBytime(Hosttime);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return result;
	}
	
	
	// 查   (赛事审核 )
	public List<Event_recordPO> findEventToAudit()
	{
		List<Event_recordPO> result = new ArrayList<Event_recordPO>();
		eventDao = new EventDAOImpl();
		try 
		{
			result = eventDao.findEventToAudit();
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		return result;
	}
	
	// 查   (赛事查询)
		public List<Event_recordPO> findEvent()
		{
			List<Event_recordPO> result = new ArrayList<Event_recordPO>();
			eventDao = new EventDAOImpl();
			try 
			{
				result = eventDao.findEventRecords();
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
			return result;
		}
	
	

	//不通过审核  置状态为  审核失败
	public void FailureEvent(Event_recordPO eventPo)
	{
		eventDao = new EventDAOImpl();		
		try 
		{
			eventDao.DeleteEvent(eventPo.getOid());
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	//通过审核
	public void PassEvent(Event_recordPO eventPo)
	{
		eventDao = new EventDAOImpl();		
		try 
		{
			eventDao.updateEvent(eventPo.getOid());
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	
	

}
