

package com.service;

import java.util.List;

import com.po.Event_recordPO;
import com.vo.Event_recordVO;

public interface EventServiceInt {

	//1:增
	void saveEvent(Event_recordVO eventVo);

	//2: 删除  真删
	void deleteEvent(Event_recordPO eventPo);

	//改
	void updateEvent(Event_recordVO eventVo);

	//按时间查找  
	List<Event_recordPO> findEventBytime(String Hosttime);

	// 查   (赛事审核 )
	List<Event_recordPO> findEventToAudit();

	// 查   (赛事查询)
	List<Event_recordPO> findEvent();

	//不通过审核  置状态为  审核失败
	void FailureEvent(Event_recordPO eventPo);

	//通过审核
	void PassEvent(Event_recordPO eventPo);

}