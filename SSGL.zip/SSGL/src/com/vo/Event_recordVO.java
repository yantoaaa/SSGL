package com.vo;
//apply表
public class Event_recordVO {
	private int oid;
	private String Eventname;
	private String Eventdetail;
	private String Hosttime;
	private String Applicator;
	private String Teacher;
	private String Host;
	private String Hostplace;
	private String Equipment;
	private String status;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	private String Eventid;
	public String getEventid() {
		return Eventid;
	}
	public void setEventid(String eventid) {
		Eventid = eventid;
	}
	public String getEventname() {
		return Eventname;
	}
	public void setEventname(String eventname) {
		Eventname = eventname;
	}
	public String getEventdetail() {
		return Eventdetail;
	}
	public void setEventdetail(String eventdetail) {
		Eventdetail = eventdetail;
	}
	public String getHosttime() {
		return Hosttime;
	}
	public void setHosttime(String hosttime) {
		Hosttime = hosttime;
	}
	public String getApplicator() {
		return Applicator;
	}
	public void setApplicator(String applicator) {
		Applicator = applicator;
	}
	public String getTeacher() {
		return Teacher;
	}
	public void setTeacher(String teacher) {
		Teacher = teacher;
	}
	public String getHost() {
		return Host;
	}
	public void setHost(String host) {
		Host = host;
	}
	public String getHostplace() {
		return Hostplace;
	}
	public void setHostplace(String hostplace) {
		Hostplace = hostplace;
	}
	public String getEquipment() {
		return Equipment;
	}
	public void setEquipment(String equipment) {
		Equipment = equipment;
	}

	
	
	
	public boolean isTransient() {
		return getOid() < 1;
	}

}
