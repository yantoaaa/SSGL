﻿package com.dao;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import org.hibernate.*;
import org.hibernate.criterion.*;
import com.hibservpro.HibernateServiceProvider;

import com.po.Event_recordPO;
import com.vo.Event_recordVO;

//DAO接口实现类
public class EventDAOImpl implements EventDAOInt {
	private Event_recordPO eventPo;

	private HibernateServiceProvider hsp = new HibernateServiceProvider();

	// 保存一个 增
	public void saveEvent(Event_recordPO eventPo) throws Exception {
		Transaction t = null;
		Session session = hsp.getSession();
		try {

			t = session.beginTransaction();
			session.saveOrUpdate(eventPo);
			t.commit();
		} catch (HibernateException e) {
			if (t != null) {
				t.rollback();
				e.printStackTrace();
			}
		} finally {
			session.close();
		}
	}

	// 按OID删除一个 真删除
	public void deleteByOid(int oid) throws Exception {
		Transaction t = null;
		Session session = hsp.getSession();
		try {

			t = session.beginTransaction();
			session.delete(session.get(Event_recordPO.class, oid)); // session的delete方法按主键删除一条记录
			t.commit();
		} catch (HibernateException e) {
			if (t != null) {
				t.rollback();
				e.printStackTrace();
			}
		} finally {
			session.close();
		}
	}

	// 改
	public void updateEventRecord(Event_recordPO eventPo) throws Exception {

		Transaction t = null;
		Session session = hsp.getSession();
		try {

			t = session.beginTransaction();

			session.update(eventPo);
			t.commit();
		} catch (HibernateException e) {
			if (t != null) {
				t.rollback();
				e.printStackTrace();
			}
		} finally {
			session.close();
		}

	}

	// 点击去审核 找到待审核的记录 查 （赛事审核）
	@SuppressWarnings("unchecked")
	public List<Event_recordPO> findEventToAudit() throws Exception {
		String status = "待审核";
		Session session = hsp.getSession();
		Transaction tx = null;
		Query query = null;
		List<Event_recordPO> result = new ArrayList<Event_recordPO>();
		Event_recordPO eventPo = new Event_recordPO();// books用于暂存从结果集中逐条取出的记录，每条记录必须再封装为BookPO实例，用于输出
		try {
			String hql = "from Event_recordPO as s where s.status = ?";
			tx = session.beginTransaction();
			query = session.createQuery(hql);
			query.setString(0, status);
			result = query.list();
			Iterator<Event_recordPO> b = result.iterator();
			System.out.println(b.next());
			while (b.hasNext()) {
				System.out.println("待审核不为空");
				eventPo = (Event_recordPO) b.next();
				// System.out.println(staffVo.getName());

			}
			tx.commit();

		} catch (HibernateException he) {
			if (tx != null) {
				tx.rollback();
			}
			throw he;
		} finally {
			session.close();
			return result;
		}

	}

	// 找到通过审核的记录 查 （赛事查询）
	public List<Event_recordPO> findEventRecords() throws Exception {
		String status = "通过审核";
		Session session = hsp.getSession();
		Transaction tx = null;
		Query query = null;
		List<Event_recordPO> result = new ArrayList<Event_recordPO>();
		Event_recordPO eventPo = new Event_recordPO();// books用于暂存从结果集中逐条取出的记录，每条记录必须再封装为BookPO实例，用于输出
		try {
			String hql = "from Event_recordPO as s where s.status = ?";
			tx = session.beginTransaction();
			query = session.createQuery(hql);
			query.setString(0, status);
			result = query.list();
			tx.commit();

		} catch (HibernateException he) {
			if (tx != null) {
				tx.rollback();
			}
			throw he;
		} finally {
			session.close();
			return result;
		}
	}

	// 输入时间查找赛事
	public List<Event_recordPO> findEventBytime(String Hosttime) throws Exception {

		Session session = hsp.getSession();
		Transaction tx = null;
		Query query = null;
		List<Event_recordPO> result = new ArrayList<Event_recordPO>();

		try {
			String hql = "from Event_recordPO as s where s.Hosttime = ?";
			tx = session.beginTransaction();
			query = session.createQuery(hql);
			query.setString(0, Hosttime);
			result = query.list();
			tx.commit();

		} catch (HibernateException he) {
			if (tx != null) {
				tx.rollback();
			}
			throw he;
		} finally {
			session.close();
			return result;
		}

	}

	// 通过审核
	public void updateEvent(int oid) throws Exception

	{

		// staffPo.setStatus("审核失败");
		String delete = "通过审核";
		Session session = hsp.getSession();
		Transaction tx = null;
		try {
			String hql = "update Event_recordPO set status=? where oid=?";
			tx = session.beginTransaction();
			Query query = (Query) session.createQuery(hql);
			query.setString(0, delete);
			query.setLong(1, oid);
			query.executeUpdate();
			tx.commit();

		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
				e.printStackTrace();
			}
		} finally {
			session.close();
		}

	}

	// 审核失败
	public void DeleteEvent(int oid) throws Exception {

		// staffPo.setStatus("审核失败");
		String delete = "审核失败";
		Session session = hsp.getSession();
		Transaction tx = null;
		try {
			String hql = "update Event_recordPO set status=? where oid=?";
			tx = session.beginTransaction();
			Query query = (Query) session.createQuery(hql);
			query.setString(0, delete);
			query.setLong(1, oid);
			query.executeUpdate();
			tx.commit();

		} catch (HibernateException e) {
			if (tx != null) {
				tx.rollback();
				e.printStackTrace();
			}
		} finally {
			session.close();
		}

	}

	// 设置为已删除 ？？
	public void updateDeleteStaff(Event_recordPO staffPo) throws Exception {
		if (staffPo.isTransient()) {
			throw new IllegalArgumentException("can't update new book, try saving it.");
		} else {
			Transaction t = null;
			Session session = hsp.getSession();
			try {
				
				t = session.beginTransaction();
				session.saveOrUpdate(staffPo);
				t.commit();
			} catch (HibernateException e) {
				if (t != null) {
					t.rollback();
					e.printStackTrace();
				}
			} finally {
				session.close();
			}
		}
	}
}
