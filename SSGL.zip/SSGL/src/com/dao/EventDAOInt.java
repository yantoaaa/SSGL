package com.dao;

import java.util.List;

import com.po.Event_recordPO;

public interface EventDAOInt {

	//保存一个  增
	void saveEvent(Event_recordPO eventPo) throws Exception;

	//按OID删除一个  真删除
	void deleteByOid(int oid) throws Exception;

	//改   
	void updateEventRecord(Event_recordPO eventPo) throws Exception;


	//点击去审核  找到待审核的记录       查   （赛事审核）
	List<Event_recordPO> findEventToAudit() throws Exception;

	//找到通过审核的记录   查  （赛事查询）
	List<Event_recordPO> findEventRecords() throws Exception;

	//输入时间查找赛事
	List<Event_recordPO> findEventBytime(String Hosttime) throws Exception;

	//更新一个    审核时 更改以及 设置状态  通过审核
	void updateEvent(int oid) throws Exception;

	//  审核失败   
	void DeleteEvent(int oid) throws Exception;

	//设置为已删除  ？？
	void updateDeleteStaff(Event_recordPO staffPo) throws Exception;

}